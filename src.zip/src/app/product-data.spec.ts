import { ProductData } from './product-data';

describe('ProductData', () => {
  it('should create an instance', () => {
    expect(new ProductData()).toBeTruthy();
  });
});
