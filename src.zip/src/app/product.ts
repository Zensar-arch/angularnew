export class Product {
    productId:number;
    name:string;
    brand:string;
    price:number;
}
